package org.talend.designer.codegen.translators.xml;

import org.talend.core.model.process.INode;
import org.talend.core.model.metadata.IMetadataTable;
import org.talend.core.model.metadata.IMetadataColumn;
import org.talend.designer.codegen.config.CodeGeneratorArgument;
import org.talend.core.model.process.ElementParameterParser;
import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Map;
import org.talend.core.model.process.IConnection;
import org.talend.core.model.process.IConnectionCategory;
import org.talend.core.model.metadata.types.JavaTypesManager;
import org.talend.core.model.metadata.types.JavaType;
import org.talend.core.model.utils.NodeUtil;
import org.talend.core.model.process.EConnectionType;

/**
 * add by xzhang
 */
public class TWriteXMLFieldOutMainJava {

  protected static String nl;
  public static synchronized TWriteXMLFieldOutMainJava create(String lineSeparator)
  {
    nl = lineSeparator;
    TWriteXMLFieldOutMainJava result = new TWriteXMLFieldOutMainJava();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "\t\t\t\tlog.debug(\"";
  protected final String TEXT_2 = " - Retrieving records from the datasource.\");" + NL + "\t\t\t";
  protected final String TEXT_3 = NL + "\t\t\t\tlog.debug(\"";
  protected final String TEXT_4 = " - Retrieved records count: \"+ nb_line_";
  protected final String TEXT_5 = " + \" .\");" + NL + "\t\t\t";
  protected final String TEXT_6 = " - Retrieved records count: \"+ globalMap.get(\"";
  protected final String TEXT_7 = "_NB_LINE\") + \" .\");" + NL + "\t\t\t";
  protected final String TEXT_8 = " - Written records count: \" + nb_line_";
  protected final String TEXT_9 = NL + "\t\t\t\tfinal StringBuffer log4jSb_";
  protected final String TEXT_10 = " = new StringBuffer();" + NL + "\t\t\t";
  protected final String TEXT_11 = " - Retrieving the record \" + (nb_line_";
  protected final String TEXT_12 = ") + \".\");" + NL + "\t\t\t";
  protected final String TEXT_13 = " - Writing the record \" + nb_line_";
  protected final String TEXT_14 = " + \" to the file.\");" + NL + "\t\t\t";
  protected final String TEXT_15 = " - Processing the record \" + nb_line_";
  protected final String TEXT_16 = " + \".\");" + NL + "\t\t\t";
  protected final String TEXT_17 = " - Processed records count: \" + nb_line_";
  protected final String TEXT_18 = NL + "                log.error(message_";
  protected final String TEXT_19 = ");";
  protected final String TEXT_20 = NL + "                System.err.println(message_";
  protected final String TEXT_21 = NL + "\t\tvalueMap_";
  protected final String TEXT_22 = ".get(\"";
  protected final String TEXT_23 = "\")";
  protected final String TEXT_24 = NL + "\t\tarraysValueMap_";
  protected final String TEXT_25 = NL + "\t(";
  protected final String TEXT_26 = NL + "\t\t";
  protected final String TEXT_27 = ".";
  protected final String TEXT_28 = " != null?";
  protected final String TEXT_29 = NL + "    \t\tFormatterUtils.format_Number(";
  protected final String TEXT_30 = ".toPlainString(), ";
  protected final String TEXT_31 = ",";
  protected final String TEXT_32 = ")\t\t\t\t\t";
  protected final String TEXT_33 = NL + "    \t\tFormatterUtils.format_Number(String.valueOf(";
  protected final String TEXT_34 = "), ";
  protected final String TEXT_35 = ")\t\t\t\t\t\t";
  protected final String TEXT_36 = NL + "            String.valueOf(";
  protected final String TEXT_37 = ")";
  protected final String TEXT_38 = NL + "            FormatterUtils.format_Date(";
  protected final String TEXT_39 = NL + "\t\t\t";
  protected final String TEXT_40 = ".toPlainString()";
  protected final String TEXT_41 = NL + "            new String(";
  protected final String TEXT_42 = NL + "\t\t\tnestXMLTool_";
  protected final String TEXT_43 = ".objectToString(";
  protected final String TEXT_44 = NL + "            ";
  protected final String TEXT_45 = ".toString()";
  protected final String TEXT_46 = ":";
  protected final String TEXT_47 = "null";
  protected final String TEXT_48 = NL + "\t\t)";
  protected final String TEXT_49 = "_";
  protected final String TEXT_50 = ".setName(\"";
  protected final String TEXT_51 = "\");";
  protected final String TEXT_52 = NL + "\t\torg.dom4j.Element ";
  protected final String TEXT_53 = ";" + NL + "\t\tif (";
  protected final String TEXT_54 = ".getNamespaceForPrefix(\"";
  protected final String TEXT_55 = "\") == null) {";
  protected final String TEXT_56 = " = org.dom4j.DocumentHelper.createElement(\"";
  protected final String TEXT_57 = "\");" + NL + "        } else {" + NL + "        \t";
  protected final String TEXT_58 = "\");" + NL + "        }";
  protected final String TEXT_59 = NL + "        if(orders_";
  protected final String TEXT_60 = "[";
  protected final String TEXT_61 = "]==0){" + NL + "        \torders_";
  protected final String TEXT_62 = "] = ";
  protected final String TEXT_63 = ";" + NL + "        }" + NL + "        if(";
  protected final String TEXT_64 = " < orders_";
  protected final String TEXT_65 = ".length){" + NL + "        \t\torders_";
  protected final String TEXT_66 = "] = 0;" + NL + "        }";
  protected final String TEXT_67 = NL + "        ";
  protected final String TEXT_68 = ".elements().add(orders_";
  protected final String TEXT_69 = "]++,";
  protected final String TEXT_70 = " = ";
  protected final String TEXT_71 = ".addElement(\"";
  protected final String TEXT_72 = NL + "\t\tsubTreeRootParent_";
  protected final String TEXT_73 = ";";
  protected final String TEXT_74 = NL + "\t\tif(";
  protected final String TEXT_75 = "!=null){";
  protected final String TEXT_76 = NL + "            nestXMLTool_";
  protected final String TEXT_77 = " .parseAndAdd(";
  protected final String TEXT_78 = NL + "        }";
  protected final String TEXT_79 = NL + "\t\telse{" + NL + "\t\t\tnestXMLTool_";
  protected final String TEXT_80 = ",\"\");" + NL + "\t\t\t";
  protected final String TEXT_81 = ".addAttribute(\"xsi:nil\",\"true\");" + NL + "\t\t}";
  protected final String TEXT_82 = "!=null){" + NL + "\t\t\tnestXMLTool_";
  protected final String TEXT_83 = " .setText(";
  protected final String TEXT_84 = NL + "                    // Node ";
  protected final String TEXT_85 = " has custom attribute ";
  protected final String TEXT_86 = ".addAttribute(\"type\", \"string\");" + NL + "\t\t\t";
  protected final String TEXT_87 = ".addAttribute(\"class\", \"string\");" + NL + "\t\t\t\t";
  protected final String TEXT_88 = ".addAttribute(\"type\", \"boolean\");";
  protected final String TEXT_89 = ".addAttribute(\"type\", \"number\");";
  protected final String TEXT_90 = NL + "\t\t}";
  protected final String TEXT_91 = NL + "\t\telse {" + NL + "\t\t\tnestXMLTool_";
  protected final String TEXT_92 = ",\"null\");" + NL + "\t\t\t";
  protected final String TEXT_93 = ".addAttribute(\"null\", \"true\");" + NL + "\t\t}";
  protected final String TEXT_94 = NL + "\t\telse{" + NL + "\t\t\t";
  protected final String TEXT_95 = ".setText(\"\");" + NL + "\t\t\t";
  protected final String TEXT_96 = NL + "\t\tnestXMLTool_";
  protected final String TEXT_97 = ".parseAndAdd(";
  protected final String TEXT_98 = ",\"";
  protected final String TEXT_99 = "!=null){" + NL + "\t\t\t";
  protected final String TEXT_100 = ".addAttribute(\"";
  protected final String TEXT_101 = "\",";
  protected final String TEXT_102 = ");" + NL + "\t\t}";
  protected final String TEXT_103 = "\", \"";
  protected final String TEXT_104 = ".addNamespace(\"";
  protected final String TEXT_105 = "\",TalendString.replaceSpecialCharForXML(";
  protected final String TEXT_106 = "));";
  protected final String TEXT_107 = NL + "        \t";
  protected final String TEXT_108 = ".setQName(org.dom4j.DocumentHelper.createQName(";
  protected final String TEXT_109 = ".getName()," + NL + "        \torg.dom4j.DocumentHelper.createNamespace(\"\",TalendString.replaceSpecialCharForXML(";
  protected final String TEXT_110 = "))));";
  protected final String TEXT_111 = "\",TalendString.replaceSpecialCharForXML(\"";
  protected final String TEXT_112 = "\"));";
  protected final String TEXT_113 = ".getName()," + NL + "        \torg.dom4j.DocumentHelper.createNamespace(\"\",TalendString.replaceSpecialCharForXML(\"";
  protected final String TEXT_114 = "\"))));";
  protected final String TEXT_115 = NL + "    \t// buffer the start tabs to group buffer" + NL + "    \tgroupBuffer_";
  protected final String TEXT_116 = "] = buf_";
  protected final String TEXT_117 = ".toString();" + NL + "        buf_";
  protected final String TEXT_118 = " = new StringBuffer();";
  protected final String TEXT_119 = NL + "\t\tstartTabs_";
  protected final String TEXT_120 = NL + "\t\tout_";
  protected final String TEXT_121 = ".write(buf_";
  protected final String TEXT_122 = ".toString());" + NL + "        buf_";
  protected final String TEXT_123 = NL + "\t\tif( false";
  protected final String TEXT_124 = " || valueMap_";
  protected final String TEXT_125 = "\") != null";
  protected final String TEXT_126 = " || true " + NL + "                    \t";
  protected final String TEXT_127 = NL + "\t\t){";
  protected final String TEXT_128 = NL + "\t\tbuf_";
  protected final String TEXT_129 = ".append(\"";
  protected final String TEXT_130 = "\");" + NL + "\t\tbuf_";
  protected final String TEXT_131 = "<";
  protected final String TEXT_132 = ".append(\" xmlns:xsi=\\\"http://www.w3.org/2001/XMLSchema-instance\\\"\");" + NL + "\t\tbuf_";
  protected final String TEXT_133 = ".append(\" xsi:noNamespaceSchemaLocation= \\\"\"+";
  protected final String TEXT_134 = "+\"\\\"\");";
  protected final String TEXT_135 = "==null){" + NL + "\t\t\tbuf_";
  protected final String TEXT_136 = ".append(\" xsi:nil=\\\"true\\\"\");" + NL + "\t\t}";
  protected final String TEXT_137 = ".append(\">\");";
  protected final String TEXT_138 = "</";
  protected final String TEXT_139 = ">\");";
  protected final String TEXT_140 = ".append(\"</";
  protected final String TEXT_141 = "!=null){" + NL + "\t\t\tbuf_";
  protected final String TEXT_142 = ".append(";
  protected final String TEXT_143 = ".append(TalendString.checkCDATAForXML(";
  protected final String TEXT_144 = "));" + NL + "\t\t}";
  protected final String TEXT_145 = ".append(\" ";
  protected final String TEXT_146 = "=\\\"\"+TalendString.replaceSpecialCharForXML(";
  protected final String TEXT_147 = ")+\"\\\"\");" + NL + "\t\t}";
  protected final String TEXT_148 = "=\\\"\"+TalendString.replaceSpecialCharForXML(\"";
  protected final String TEXT_149 = "\")+\"\\\"\");";
  protected final String TEXT_150 = NL + "        \tbuf_";
  protected final String TEXT_151 = ".append(\" xmlns=\\\"\"+TalendString.replaceSpecialCharForXML(";
  protected final String TEXT_152 = ")+\"\\\"\");";
  protected final String TEXT_153 = NL + "\t\t\tbuf_";
  protected final String TEXT_154 = ".append(\" xmlns:";
  protected final String TEXT_155 = ".append(\" xmlns=\\\"\"+TalendString.replaceSpecialCharForXML(\"";
  protected final String TEXT_156 = NL + "\tif(txf_";
  protected final String TEXT_157 = ".getLastException()!=null) {" + NL + "\t\tcurrentComponent = txf_";
  protected final String TEXT_158 = ".getCurrentComponent();" + NL + "\t\tthrow txf_";
  protected final String TEXT_159 = ".getLastException();" + NL + "\t}" + NL + "\t" + NL + "\tif(txf_";
  protected final String TEXT_160 = ".getLastError()!=null) {" + NL + "\t\tthrow txf_";
  protected final String TEXT_161 = ".getLastError();" + NL + "\t}";
  protected final String TEXT_162 = NL + "\tnb_line_";
  protected final String TEXT_163 = "++;";
  protected final String TEXT_164 = NL + "\tclass ToStringHelper_";
  protected final String TEXT_165 = " {" + NL + "\t    public String toString(final Object value) {" + NL + "\t        return value != null ? value.toString() : null;" + NL + "\t    }" + NL + "\t}" + NL + "\tfinal ToStringHelper_";
  protected final String TEXT_166 = " helper_";
  protected final String TEXT_167 = " = new ToStringHelper_";
  protected final String TEXT_168 = "();" + NL + "" + NL + "\tvalueMap_";
  protected final String TEXT_169 = ".clear();";
  protected final String TEXT_170 = NL + "\tarraysValueMap_";
  protected final String TEXT_171 = NL + "\tvalueMap_";
  protected final String TEXT_172 = ".put(\"";
  protected final String TEXT_173 = "\", helper_";
  protected final String TEXT_174 = ".toString(";
  protected final String TEXT_175 = NL + "\tflowValues_";
  protected final String TEXT_176 = " = new java.util.HashMap<String,String>();" + NL + "\tflowValues_";
  protected final String TEXT_177 = ".putAll(valueMap_";
  protected final String TEXT_178 = ");" + NL + "\tflows_";
  protected final String TEXT_179 = ".add(flowValues_";
  protected final String TEXT_180 = NL + "\t\tString strTemp_";
  protected final String TEXT_181 = " = \"\";";
  protected final String TEXT_182 = "\t\tstrTemp_";
  protected final String TEXT_183 = " = strTemp_";
  protected final String TEXT_184 = " + valueMap_";
  protected final String TEXT_185 = "\")" + NL + "\t\t\t\t\t\t\t+ valueMap_";
  protected final String TEXT_186 = "\").length();";
  protected final String TEXT_187 = NL + "\tif(strCompCache_";
  protected final String TEXT_188 = "==null){" + NL + "\t\tstrCompCache_";
  protected final String TEXT_189 = "=strTemp_";
  protected final String TEXT_190 = ";" + NL + "\t\t";
  protected final String TEXT_191 = NL + "            \trowStructOutput_";
  protected final String TEXT_192 = ";" + NL + "            \t";
  protected final String TEXT_193 = NL + "\t}else{";
  protected final String TEXT_194 = NL + "\t\t//the data read is different from the data read last time. " + NL + "\t\tif(!strCompCache_";
  protected final String TEXT_195 = ".equals(strTemp_";
  protected final String TEXT_196 = ")){\t";
  protected final String TEXT_197 = NL + "\t\t\tdoc_";
  protected final String TEXT_198 = ".getRootElement().addAttribute(\"xsi:noNamespaceSchemaLocation\", ";
  protected final String TEXT_199 = ");" + NL + "\t\t    doc_";
  protected final String TEXT_200 = ".getRootElement().addNamespace(\"xsi\", \"http://www.w3.org/2001/XMLSchema-instance\");";
  protected final String TEXT_201 = "  " + NL + "    \t\tnestXMLTool_";
  protected final String TEXT_202 = ".replaceDefaultNameSpace(doc_";
  protected final String TEXT_203 = ".getRootElement());";
  protected final String TEXT_204 = NL + "    \t\tnestXMLTool_";
  protected final String TEXT_205 = ".removeEmptyElement(doc_";
  protected final String TEXT_206 = "\t\t\t" + NL + "\t\t\tjava.io.StringWriter strWriter_";
  protected final String TEXT_207 = " = new java.io.StringWriter();\t" + NL + "\t\t\torg.dom4j.io.XMLWriter output_";
  protected final String TEXT_208 = " = new org.dom4j.io.XMLWriter(strWriter_";
  protected final String TEXT_209 = ", format_";
  protected final String TEXT_210 = ");" + NL + "\t\t\toutput_";
  protected final String TEXT_211 = ".write(doc_";
  protected final String TEXT_212 = ");" + NL + "\t\t    output_";
  protected final String TEXT_213 = ".close();" + NL + "\t\t\t";
  protected final String TEXT_214 = NL + "\t\t\tString removeHeader_";
  protected final String TEXT_215 = " = strWriter_";
  protected final String TEXT_216 = ".toString();" + NL + "\t\t\tif(removeHeader_";
  protected final String TEXT_217 = ".indexOf(\"<?xml\") >=0 ){" + NL + "\t\t\t\tremoveHeader_";
  protected final String TEXT_218 = " = removeHeader_";
  protected final String TEXT_219 = ".substring(removeHeader_";
  protected final String TEXT_220 = ".indexOf(\"?>\")+3);" + NL + "\t\t\t}" + NL + "\t\t\tlistGroupby_";
  protected final String TEXT_221 = ".add(removeHeader_";
  protected final String TEXT_222 = NL + "                map_";
  protected final String TEXT_223 = ".put(\"json_";
  protected final String TEXT_224 = "\",strWriter_";
  protected final String TEXT_225 = ".toString());" + NL + "                listGroupby_";
  protected final String TEXT_226 = ".add(map_";
  protected final String TEXT_227 = NL + "\t\t\t\t  \t\t  ";
  protected final String TEXT_228 = " row_";
  protected final String TEXT_229 = " = new ";
  protected final String TEXT_230 = "();" + NL + "\t\t\t\t\t\t  ";
  protected final String TEXT_231 = NL + "\t\t\t\t\t\t\t\trow_";
  protected final String TEXT_232 = " = rowStructOutput_";
  protected final String TEXT_233 = ";" + NL + "\t\t\t\t\t\t\t\t";
  protected final String TEXT_234 = NL + "\t\t\t\t\t     \t\trow_";
  protected final String TEXT_235 = ".toString();" + NL + "\t\t\t\t\t     \t\tlistGroupby_";
  protected final String TEXT_236 = ".add(row_";
  protected final String TEXT_237 = ");" + NL + "\t\t\t\t\t";
  protected final String TEXT_238 = NL + "\t\t\t\t\t\t\t\t\t\t    listGroupby_";
  protected final String TEXT_239 = ".add(strWriter_";
  protected final String TEXT_240 = ".toString());" + NL + "\t\t\t\t\t\t\t\t";
  protected final String TEXT_241 = NL + "\t\t    doc_";
  protected final String TEXT_242 = ".clearContent();" + NL + "\t\t\tneedRoot_";
  protected final String TEXT_243 = " = true;" + NL + "\t\t\tfor(int i_";
  protected final String TEXT_244 = "=0;i_";
  protected final String TEXT_245 = "<orders_";
  protected final String TEXT_246 = ".length;i_";
  protected final String TEXT_247 = "++){" + NL + "\t\t\t\torders_";
  protected final String TEXT_248 = "[i_";
  protected final String TEXT_249 = "] = 0;" + NL + "\t\t\t}" + NL + "\t\t\t" + NL + "\t\t\tif(groupbyList_";
  protected final String TEXT_250 = " != null && groupbyList_";
  protected final String TEXT_251 = ".size() >= 0){" + NL + "\t\t\t\tgroupbyList_";
  protected final String TEXT_252 = ".clear();" + NL + "\t\t\t}" + NL + "\t\t\tstrCompCache_";
  protected final String TEXT_253 = NL + "\t}" + NL;
  protected final String TEXT_254 = "  = new java.util.HashMap();";
  protected final String TEXT_255 = NL + "                    map_";
  protected final String TEXT_256 = NL + "\torg.dom4j.Element subTreeRootParent_";
  protected final String TEXT_257 = " = null;" + NL + "\t" + NL + "\t// build root xml tree " + NL + "\tif (needRoot_";
  protected final String TEXT_258 = ") {" + NL + "\t\tneedRoot_";
  protected final String TEXT_259 = "=false;";
  protected final String TEXT_260 = NL + "\t\troot4Group_";
  protected final String TEXT_261 = " = subTreeRootParent_";
  protected final String TEXT_262 = ";" + NL + "\t}else{" + NL + "\t\tsubTreeRootParent_";
  protected final String TEXT_263 = "=root4Group_";
  protected final String TEXT_264 = ";" + NL + "\t}" + NL + "\t// build group xml tree ";
  protected final String TEXT_265 = NL + "\tboolean isNewElememt = false;";
  protected final String TEXT_266 = NL + "\tif(isNewElememt || groupbyList_";
  protected final String TEXT_267 = ".size()<=";
  protected final String TEXT_268 = " || groupbyList_";
  protected final String TEXT_269 = ".get(";
  protected final String TEXT_270 = ")==null";
  protected final String TEXT_271 = NL + "\t|| ( groupbyList_";
  protected final String TEXT_272 = ").get(";
  protected final String TEXT_273 = ")!=null " + NL + "\t\t? !groupbyList_";
  protected final String TEXT_274 = ").equals(";
  protected final String TEXT_275 = ") " + NL + "\t\t: ";
  protected final String TEXT_276 = "!=null )";
  protected final String TEXT_277 = NL + "\t){";
  protected final String TEXT_278 = NL + "\t\tif(groupbyList_";
  protected final String TEXT_279 = "){" + NL + "        \tgroupbyList_";
  protected final String TEXT_280 = ".add(new java.util.ArrayList<String>());" + NL + "        }else{" + NL + "        \tgroupbyList_";
  protected final String TEXT_281 = ").clear();" + NL + "        }";
  protected final String TEXT_282 = NL + "\t\tgroupbyList_";
  protected final String TEXT_283 = ").add(";
  protected final String TEXT_284 = NL + "        isNewElememt=true;" + NL + "        if(groupElementList_";
  protected final String TEXT_285 = "){" + NL + "\t\t\tgroupElementList_";
  protected final String TEXT_286 = ".add(group";
  protected final String TEXT_287 = "__";
  protected final String TEXT_288 = ");" + NL + "        }else{" + NL + "        \tgroupElementList_";
  protected final String TEXT_289 = ".set(";
  protected final String TEXT_290 = ",group";
  protected final String TEXT_291 = ");" + NL + "        }" + NL + "        " + NL + "\t}else{" + NL + "\t\tsubTreeRootParent_";
  protected final String TEXT_292 = "=groupElementList_";
  protected final String TEXT_293 = ");" + NL + "\t}";
  protected final String TEXT_294 = NL + "\t// build loop xml tree";
  protected final String TEXT_295 = ")){";
  protected final String TEXT_296 = NL + NL + "\t\t // write the endtag to the StringWriter:strWriter_tWriteXMLField_1_Out" + NL + "\t\t // close the bufferWriter" + NL + "\t\t // add the data in strWriter_tWriteXMLField_1_Out to listGroupby\t\t\t\t\t\t\t " + NL + "" + NL + "\t\tif (preUnNullMaxIndex_";
  protected final String TEXT_297 = " >= 0) {" + NL + "\t        // output all buffer" + NL + "\t        for (int j_";
  protected final String TEXT_298 = " = 0; j_";
  protected final String TEXT_299 = " <= preUnNullMaxIndex_";
  protected final String TEXT_300 = "; j_";
  protected final String TEXT_301 = "++) {" + NL + "\t            if (startTabs_";
  protected final String TEXT_302 = "[j_";
  protected final String TEXT_303 = "] != null)" + NL + "\t                out_";
  protected final String TEXT_304 = ".write(startTabs_";
  protected final String TEXT_305 = "]);" + NL + "\t        }" + NL + "\t" + NL + "\t        if (preUnNullMaxIndex_";
  protected final String TEXT_306 = " < preNewTabIndex_";
  protected final String TEXT_307 = " ) {" + NL + "\t\t\t\tfor (int i_";
  protected final String TEXT_308 = " = preNewTabIndex_";
  protected final String TEXT_309 = " - 1; i_";
  protected final String TEXT_310 = " >= 0; i_";
  protected final String TEXT_311 = "--) {" + NL + "                \tif(endTabs_";
  protected final String TEXT_312 = "]!=null){" + NL + "                \t\tout_";
  protected final String TEXT_313 = ".write(endTabs_";
  protected final String TEXT_314 = "]);" + NL + "                \t}                \t" + NL + "\t                out_";
  protected final String TEXT_315 = ".write(\"";
  protected final String TEXT_316 = "\");" + NL + "\t                out_";
  protected final String TEXT_317 = ".write(endTabStrs_";
  protected final String TEXT_318 = ".get(i_";
  protected final String TEXT_319 = "));" + NL + "\t            }" + NL + "\t        } else {" + NL + "\t            for (int i_";
  protected final String TEXT_320 = " = preUnNullMaxIndex_";
  protected final String TEXT_321 = "; i_";
  protected final String TEXT_322 = "]);" + NL + "                \t}" + NL + "                \tout_";
  protected final String TEXT_323 = "));" + NL + "\t            }" + NL + "\t        }" + NL + "\t    }";
  protected final String TEXT_324 = NL + "\t\tfor (int i_";
  protected final String TEXT_325 = " = endTabStrs_";
  protected final String TEXT_326 = ".size() - 1; i_";
  protected final String TEXT_327 = "--) {" + NL + "        \tif(endTabs_";
  protected final String TEXT_328 = "]!=null){" + NL + "        \t\tout_";
  protected final String TEXT_329 = "]);" + NL + "        \t}" + NL + "\t        out_";
  protected final String TEXT_330 = "\");" + NL + "\t        out_";
  protected final String TEXT_331 = "));" + NL + "\t    }";
  protected final String TEXT_332 = " = 0; i_";
  protected final String TEXT_333 = " < endTabs_";
  protected final String TEXT_334 = ".length; i_";
  protected final String TEXT_335 = "++) {" + NL + "\t\t\tstartTabs_";
  protected final String TEXT_336 = "] = null;" + NL + "\t\t\tendTabs_";
  protected final String TEXT_337 = "] = null;" + NL + "\t\t}" + NL + "//\t\tendTabStrs_";
  protected final String TEXT_338 = ".clear();" + NL + "\t\tout_";
  protected final String TEXT_339 = "\");" + NL + "\t\tout_";
  protected final String TEXT_340 = ".close();" + NL + "\t\tlistGroupby_";
  protected final String TEXT_341 = ".toString());" + NL + "" + NL + "\t\t//create a new StringWriter and BufferWriter" + NL + "\t\t//write the head title to the StringWriter\t\t" + NL + "\t\tstrWriter_";
  protected final String TEXT_342 = " = new java.io.StringWriter();" + NL + "\t\tout_";
  protected final String TEXT_343 = " = new java.io.BufferedWriter(strWriter_";
  protected final String TEXT_344 = ".write(\"<?xml version=\\\"1.0\\\" encoding=\\\"\"+";
  protected final String TEXT_345 = "+\"\\\"?>\");" + NL + "\t\tout_";
  protected final String TEXT_346 = NL + NL + "\t\tneedRoot_";
  protected final String TEXT_347 = " = true;" + NL + "\t\tstrCompCache_";
  protected final String TEXT_348 = ";" + NL + "\t\tpreNewTabIndex_";
  protected final String TEXT_349 = " = -1;";
  protected final String TEXT_350 = "\t" + NL + "\t}\t" + NL + "\t" + NL + "\tStringBuffer buf_";
  protected final String TEXT_351 = " = new StringBuffer();" + NL + "\t//init value is 0 not -1, because it will output the root tab when all the row value is null." + NL + "\tint unNullMaxIndex_";
  protected final String TEXT_352 = " = 0;" + NL + "" + NL + "\t// build root xml tree " + NL + "\tif (needRoot_";
  protected final String TEXT_353 = NL + "\t\t){" + NL + "\t\t\tunNullMaxIndex_";
  protected final String TEXT_354 = ";" + NL + "\t\t}";
  protected final String TEXT_355 = NL + "\t\tendTabs_";
  protected final String TEXT_356 = ".toString();" + NL + "\t\tbuf_";
  protected final String TEXT_357 = NL + "\t}" + NL + "\t" + NL + "\t// build group xml tree ";
  protected final String TEXT_358 = NL + "\tboolean isNewElememt = false;" + NL + "\t//The index of group element which is the first new group in groups." + NL + "\tint newTabIndex_";
  protected final String TEXT_359 = " = -1;" + NL + "\t//Buffer all group tab XML, then set to startTabBuffer." + NL + "    String[] groupBuffer_";
  protected final String TEXT_360 = " = new String[";
  protected final String TEXT_361 = "];" + NL + "    String[] groupEndBuffer_";
  protected final String TEXT_362 = "];";
  protected final String TEXT_363 = NL + NL + "\t// need a new group element ";
  protected final String TEXT_364 = " or not" + NL + "\tif(isNewElememt || groupbyList_";
  protected final String TEXT_365 = NL + "\t){" + NL + "\t\t// Is the first new element in groups." + NL + "\t\tif(!isNewElememt && groupbyList_";
  protected final String TEXT_366 = ".size()>";
  protected final String TEXT_367 = "){" + NL + "\t\t\tnewTabIndex_";
  protected final String TEXT_368 = ";" + NL + "\t\t}" + NL + "" + NL + "\t\t// count the groupby element" + NL + "\t\tif(groupbyList_";
  protected final String TEXT_369 = NL + "        isNewElememt=true;" + NL + "\t}" + NL + "\t" + NL + "\t// subtree XML string generate";
  protected final String TEXT_370 = NL + "\tif( false";
  protected final String TEXT_371 = NL + "\t){" + NL + "\t\tunNullMaxIndex_";
  protected final String TEXT_372 = ";" + NL + "\t}";
  protected final String TEXT_373 = NL + "\t// buffer the end tabs to group buffer" + NL + "\tgroupEndBuffer_";
  protected final String TEXT_374 = ".toString();" + NL + "    buf_";
  protected final String TEXT_375 = NL + "\t//output the previous groups as there's a new group" + NL + "    if (newTabIndex_";
  protected final String TEXT_376 = " >= 0 && preNewTabIndex_";
  protected final String TEXT_377 = "!=-1) {" + NL + "        //out_";
  protected final String TEXT_378 = ".newLine();//Track code";
  protected final String TEXT_379 = NL + "\t\t// output unNull tabs in start tabs buffer" + NL + "        if (preUnNullMaxIndex_";
  protected final String TEXT_380 = " >= 0) {" + NL + "            for (int i_";
  protected final String TEXT_381 = " < startTabs_";
  protected final String TEXT_382 = "++) {" + NL + "                if (i_";
  protected final String TEXT_383 = ") {" + NL + "                    if (startTabs_";
  protected final String TEXT_384 = "] != null) {" + NL + "                        out_";
  protected final String TEXT_385 = "]);" + NL + "                    }" + NL + "                    startTabs_";
  protected final String TEXT_386 = "] = null;" + NL + "                }" + NL + "            }" + NL + "        }";
  protected final String TEXT_387 = NL + "\t\t//output all start tabs buffer" + NL + "\t\tfor (int i_";
  protected final String TEXT_388 = "++) {" + NL + "            if (startTabs_";
  protected final String TEXT_389 = "] != null) {" + NL + "                out_";
  protected final String TEXT_390 = "]);" + NL + "            }" + NL + "            startTabs_";
  protected final String TEXT_391 = "] = null;" + NL + "        }";
  protected final String TEXT_392 = NL + "        // output endtabs" + NL + "        if (preUnNullMaxIndex_";
  protected final String TEXT_393 = " >= preNewTabIndex_";
  protected final String TEXT_394 = NL + "            && preUnNullMaxIndex_";
  protected final String TEXT_395 = " >= ";
  protected final String TEXT_396 = " + newTabIndex_";
  protected final String TEXT_397 = ") {" + NL + "            for (int i_";
  protected final String TEXT_398 = "--) {" + NL + "            \tif(endTabs_";
  protected final String TEXT_399 = "]!=null){" + NL + "            \t\tout_";
  protected final String TEXT_400 = "]);" + NL + "            \t}" + NL + "            \tendTabs_";
  protected final String TEXT_401 = "] = null;" + NL + "                out_";
  protected final String TEXT_402 = "\");" + NL + "                out_";
  protected final String TEXT_403 = NL + "                        .get(i_";
  protected final String TEXT_404 = "));" + NL + "            }" + NL + "        } else {";
  protected final String TEXT_405 = NL + "            for (int i_";
  protected final String TEXT_406 = "));" + NL + "            }";
  protected final String TEXT_407 = NL + "        preNewTabIndex_";
  protected final String TEXT_408 = " = newTabIndex_";
  protected final String TEXT_409 = " + ";
  protected final String TEXT_410 = ";" + NL + "    }" + NL + "" + NL + "    // set new element groupbuffer to startbuffer" + NL + "    for (int i_";
  protected final String TEXT_411 = " < groupBuffer_";
  protected final String TEXT_412 = "++) {" + NL + "        // when newTabIndex is null, must use the perNewTabIndex" + NL + "        if (i_";
  protected final String TEXT_413 = " - ";
  protected final String TEXT_414 = ") {" + NL + "            startTabs_";
  protected final String TEXT_415 = "] = groupBuffer_";
  protected final String TEXT_416 = "];" + NL + "            endTabs_";
  protected final String TEXT_417 = "] = groupEndBuffer_";
  protected final String TEXT_418 = "];" + NL + "        }" + NL + "    }";
  protected final String TEXT_419 = NL + "\t//reset the preUnNullMaxIndex" + NL + "\tif(unNullMaxIndex_";
  protected final String TEXT_420 = ">=0){" + NL + "    \tpreUnNullMaxIndex_";
  protected final String TEXT_421 = "=unNullMaxIndex_";
  protected final String TEXT_422 = ";" + NL + "\t}else{" + NL + "\t\tif(preUnNullMaxIndex_";
  protected final String TEXT_423 = ">";
  protected final String TEXT_424 = "){" + NL + "\t\t\tpreUnNullMaxIndex_";
  protected final String TEXT_425 = "=";
  protected final String TEXT_426 = ";" + NL + "\t\t}" + NL + "\t}";
  protected final String TEXT_427 = " || true " + NL + "    \t";
  protected final String TEXT_428 = NL + "\t\t// output all buffer" + NL + "\t\tfor (int i_";
  protected final String TEXT_429 = "] != null && startTabs_";
  protected final String TEXT_430 = "].length() > 0) {" + NL + "                out_";
  protected final String TEXT_431 = "]);" + NL + "                startTabs_";
  protected final String TEXT_432 = "] = null;" + NL + "            }" + NL + "        }" + NL + "\t\tout_";
  protected final String TEXT_433 = ".toString());" + NL + "\t\tpreNewTabIndex_";
  protected final String TEXT_434 = NL + "            preUnNullMaxIndex_";
  protected final String TEXT_435 = NL;

    static class XMLNode {

        // table parameter of component
        public String name = null;

        public String path = null;

        public String type = null;

        public String column = null;
        
        public String defaultValue = null;
        
        public int order = 0;
        
        public boolean hasDefaultValue = false;

        // special node
        public int special = 0; // 1 is subtree root, 2 is subtree root parent, 4 is main

        // column
        public IMetadataColumn relatedColumn = null;

        public List<IMetadataColumn> childrenColumnList = new ArrayList<IMetadataColumn>();

        // tree variable
        public XMLNode parent = null;

        public List<XMLNode> attributes = new LinkedList<XMLNode>();

        public List<XMLNode> namespaces = new LinkedList<XMLNode>();

        public List<XMLNode> elements = new LinkedList<XMLNode>(); // the main element is the last element

        public XMLNode(String path, String type, XMLNode parent, String column, String value, int order) {
        	this.order = order;
            this.path = path;
            this.parent = parent;
            this.type = type;
            this.column = column;
            this.defaultValue = value;
            if (type.equals("ELEMENT")) {
                this.name = path.substring(path.lastIndexOf("/") + 1);
            } else {
                this.name = path;
            }
        }
        
        public boolean isMainNode(){
            return 4 == (special & 4);
        }
        
        public boolean isSubTreeRoot(){
            return 1 == (special & 1);
        }
        
        public boolean isSubTreeParent(){
            return 2 == (special & 2);
        }
    
        public int getNodeInsertIndex(){
        	int insertIndex =0;
        	if(5==(special & 5)){//group and loop main node
        		if(parent!=null && parent.elements!=null){
            		for(XMLNode tmpNode: parent.elements){
            			if(order <= tmpNode.order){
            				break;
            			}
            			insertIndex++;
            		}
        		}
        	}
        	return insertIndex;
        }
        
        public int getCurrGroupPos(){
        	int currPos =0;
        	if(5==(special & 5)){//group and loop main node
    			XMLNode tmpNode = parent;
    			while(tmpNode!=null && (5==(tmpNode.special & 5))){
    				currPos++;
    				tmpNode = tmpNode.parent;
    			}
        	}
        	return currPos;
        }
    }

    
    // return [0] is root(XMLNode), [1] is groups(List<XMLNode>), [2] loop(XMLNode)
    public Object[] getTree(List<Map<String, String>> rootTable, List<Map<String, String>> groupTable,
            List<Map<String, String>> loopTable, List<IMetadataColumn> colList) {
        List<List<Map<String, String>>> tables = new ArrayList<List<Map<String, String>>>();
        tables.add(rootTable);
        tables.add(groupTable);
        tables.add(loopTable);

        XMLNode root = null;
        List<XMLNode> mains = new ArrayList<XMLNode>();
        List<XMLNode> groups = new ArrayList<XMLNode>();
        XMLNode loop = null;

        XMLNode tmpParent = null;
        XMLNode tmpMainNode = null;
        if (loopTable == null || loopTable.size() == 0) {
            return null;
        }
        int index =0;
        int currOrder = 0;
        String mainPath = loopTable.get(0).get("PATH");
        for (List<Map<String, String>> tmpTable : tables) {
            tmpParent = tmpMainNode;
            for (Map<String, String> tmpMap : tmpTable) {
            	index++;
            	if(tmpMap.get("ORDER")!=null && !"".equals(tmpMap.get("ORDER").trim())){
            		currOrder = Integer.parseInt(tmpMap.get("ORDER"));
            	}else{
            		currOrder = index;
            	}
                XMLNode tmpNew = null;
                if (tmpMap.get("ATTRIBUTE").equals("attri")) {
                    tmpNew = new XMLNode(tmpMap.get("PATH"), "ATTRIBUTE", tmpParent, tmpMap.get("COLUMN"), tmpMap.get("VALUE"), currOrder);
                    tmpParent.attributes.add(tmpNew);
                } else if (tmpMap.get("ATTRIBUTE").equals("ns")) {
                    tmpNew = new XMLNode(tmpMap.get("PATH"), "NAMESPACE", tmpParent, tmpMap.get("COLUMN"), tmpMap.get("VALUE"), currOrder);
                    tmpParent.namespaces.add(tmpNew);
                } else {
                    if (tmpParent == null) {
                        tmpNew = new XMLNode(tmpMap.get("PATH"), "ELEMENT", tmpParent, tmpMap.get("COLUMN"), tmpMap.get("VALUE"), currOrder);
//                        tmpNew.special |= 1;
                        root = tmpNew;
                        mains.add(root);
                    } else {
                        String tmpParentPath = tmpMap.get("PATH").substring(0, tmpMap.get("PATH").lastIndexOf("/"));
                        while (tmpParent != null && !tmpParentPath.equals(tmpParent.path)) {
                            tmpParent = tmpParent.parent;
                        }
                        tmpNew = new XMLNode(tmpMap.get("PATH"), "ELEMENT", tmpParent, tmpMap.get("COLUMN"), tmpMap.get("VALUE"), currOrder);
                        tmpParent.elements.add(tmpNew);
                        if (tmpMap.get("ATTRIBUTE").equals("main")) {
                            if (tmpTable == groupTable) {
                                tmpNew.special |= 1;
                                tmpParent.special |= 2;
                                groups.add(tmpNew);
                            } else if (tmpTable == loopTable) {
                                tmpNew.special |= 1;
                                tmpParent.special |= 2;
                                loop = tmpNew;
                            }else if (tmpTable == rootTable){
                                mains.add(tmpNew);
                            }
                        }
                    }
                    if (tmpMap.get("ATTRIBUTE").equals("main")) {
                        tmpMainNode = tmpNew;
                        tmpNew.special |= 4;
                    }
                    tmpParent = tmpNew;
                }
                setIMetadataColumn(tmpNew, colList);
                setDefaultValues(tmpNew);//add by wliu
            }
        }
        return new Object[] { mains, groups, loop };
    }
    
    private void setDefaultValues(XMLNode node){
    	if(node.defaultValue != null && !"".equals(node.defaultValue)){
    		XMLNode tmp = node;
    		while(tmp !=null){
    			tmp.hasDefaultValue = true;
    			if(tmp.isMainNode()){
    				break;
    			}
    			tmp = tmp.parent;
    		}
    	}
    }

    private void setIMetadataColumn(XMLNode node, List<IMetadataColumn> colList) {
        String value = null;
        JavaType javaType = null;
        if (node.column != null && node.column.length() > 0) {
            for (IMetadataColumn column : colList) {
                if (column.getLabel().equals(node.column)) {
                    node.relatedColumn = column;
                    XMLNode tmp = node;
                    while (tmp != null) {
                        if (!tmp.childrenColumnList.contains(column)) {
                            tmp.childrenColumnList.add(column);
                        }
                        if(tmp.isMainNode()){
                            break;
                        }
                        tmp = tmp.parent;
                    }
                }
            }
        }
    }

    public List<XMLNode> getGroupByNodeList(XMLNode group) {
        List<XMLNode> list = new ArrayList<XMLNode>();
        for (XMLNode attri : group.attributes) {
            if (attri.column != null && attri.column.length() != 0) {
                list.add(attri);
            }
        }
        if (group.relatedColumn != null) {
            list.add(group);
        } else {
            for (XMLNode element : group.elements) {
                if (!element.isMainNode()) {
                    list.addAll(getGroupByNodeList(element));
                }
            }
        }
        return list;
    }

    public XMLNode removeEmptyElement(XMLNode root) {
        List<XMLNode> removeNodes = new LinkedList<XMLNode>();
        for (XMLNode attri : root.attributes) {
            if ((attri.column == null || attri.column.length() == 0) && 
            		(attri.defaultValue == null || "".equals(attri.defaultValue)) ) {
                attri.parent = null;
                removeNodes.add(attri);
            }
        }
        root.attributes.removeAll(removeNodes);

        removeNodes.clear();
        for (XMLNode ns : root.namespaces) {
            if ( (ns.column == null || ns.column.length() == 0)
            		&& (ns.defaultValue == null || "".equals(ns.defaultValue)) ) {
                ns.parent = null;
                removeNodes.add(ns);
            }
        }
        root.namespaces.removeAll(removeNodes);

        removeNodes.clear();
        for (XMLNode child : root.elements) {
            removeNodes.add(removeEmptyElement(child));
        }
        root.elements.removeAll(removeNodes);

        if (root.attributes.size() == 0 && root.namespaces.size() == 0 && root.elements.size() == 0
                && (root.column == null || root.column.length() == 0)
                && (root.defaultValue == null || "".equals(root.defaultValue)) ) {
            return root;
        } else {
            return null;
        }
    }

    public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    
	//this util class use by set log4j debug paramters
	class DefaultLog4jFileUtil {
	
		INode node = null;
	    String cid = null;
 		boolean isLog4jEnabled = false;
 		String label = null;
 		
 		public DefaultLog4jFileUtil(){
 		}
 		public DefaultLog4jFileUtil(INode node) {
 			this.node = node;
 			this.cid = node.getUniqueName();
 			this.label = cid;
			this.isLog4jEnabled = ("true").equals(org.talend.core.model.process.ElementParameterParser.getValue(node.getProcess(), "__LOG4J_ACTIVATE__"));
 		}
 		
 		public void setCid(String cid) {
 			this.cid = cid;
 		}
 		
		//for all tFileinput* components 
		public void startRetriveDataInfo() {
			if (isLog4jEnabled) {
			
    stringBuffer.append(TEXT_1);
    stringBuffer.append(label);
    stringBuffer.append(TEXT_2);
    
			}
		}
		
		public void retrievedDataNumberInfo() {
			if (isLog4jEnabled) {
			
    stringBuffer.append(TEXT_3);
    stringBuffer.append(label);
    stringBuffer.append(TEXT_4);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_5);
    
			}
		}
		
		public void retrievedDataNumberInfoFromGlobalMap(INode node) {
			if (isLog4jEnabled) {
			
    stringBuffer.append(TEXT_3);
    stringBuffer.append(label);
    stringBuffer.append(TEXT_6);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_7);
    
			}
		}
		
		//for all tFileinput* components 
		public void retrievedDataNumberInfo(INode node) {
			if (isLog4jEnabled) {
			
    stringBuffer.append(TEXT_3);
    stringBuffer.append(label);
    stringBuffer.append(TEXT_4);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_5);
    
			}
		}
		
		public void writeDataFinishInfo(INode node) {
			if(isLog4jEnabled){
			
    stringBuffer.append(TEXT_3);
    stringBuffer.append(label);
    stringBuffer.append(TEXT_8);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_5);
    
			}
		}
		
 		//TODO delete it and remove all log4jSb parameter from components
		public void componentStartInfo(INode node) {
			if (isLog4jEnabled) {
			
    stringBuffer.append(TEXT_9);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_10);
    
			}
		}
		
		//TODO rename or delete it
		public void debugRetriveData(INode node,boolean hasIncreased) {
			if(isLog4jEnabled){
			
    stringBuffer.append(TEXT_3);
    stringBuffer.append(label);
    stringBuffer.append(TEXT_11);
    stringBuffer.append(cid);
    stringBuffer.append(hasIncreased?"":"+1");
    stringBuffer.append(TEXT_12);
    
			}
		}
		
		//TODO rename or delete it
		public void debugRetriveData(INode node) {
			debugRetriveData(node,true);
		}
		
		//TODO rename or delete it
		public void debugWriteData(INode node) {
			if(isLog4jEnabled){
			
    stringBuffer.append(TEXT_3);
    stringBuffer.append(label);
    stringBuffer.append(TEXT_13);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_14);
    
			}
		}
		
		public void logCurrentRowNumberInfo() {
			if(isLog4jEnabled){
			
    stringBuffer.append(TEXT_3);
    stringBuffer.append(label);
    stringBuffer.append(TEXT_15);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_16);
    
			}
		}
		
		public void logDataCountInfo() {
			if(isLog4jEnabled){
			
    stringBuffer.append(TEXT_3);
    stringBuffer.append(label);
    stringBuffer.append(TEXT_17);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_5);
    
			}
		}

        public void logErrorMessage() {
            if(isLog4jEnabled){
            
    stringBuffer.append(TEXT_18);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_19);
    
            } else {
            
    stringBuffer.append(TEXT_20);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_19);
    
            }
        }
	}
	
	final DefaultLog4jFileUtil log4jFileUtil = new DefaultLog4jFileUtil((INode)(((org.talend.designer.codegen.config.CodeGeneratorArgument)argument).getArgument()));
	
    
//==========common part 1 begin===================================================================
CodeGeneratorArgument codeGenArgument = (CodeGeneratorArgument) argument;
INode node = (INode)codeGenArgument.getArgument();
String cid = node.getUniqueName();
String jsonField = ElementParameterParser.getValue(node, "__JSONFIELD__");
String destination4JSON = ElementParameterParser.getValue(node, "__DESTINATION__");
boolean istWriteJSONField = destination4JSON == null ? false : destination4JSON.contains("tWriteJSONField_");
boolean isQuoteAllValues = ("true").equals(ElementParameterParser.getValue(node, "__QUOTE_ALL_VALUES__"));
boolean isCompactFormat = ("true").equals(ElementParameterParser.getValue(node, "__COMPACT_FORMAT__"));
final boolean allowEmptyStrings = ("true").equals(ElementParameterParser.getValue(node, "__ALLOW_EMPTY_STRINGS__"));
final String whiteSpace;
final String rowSeparator;
if(!isCompactFormat) { // pretty format
	whiteSpace = "  ";
	rowSeparator = "\\n";
} else { // compact format
	whiteSpace = "";
	rowSeparator = "";
}
//===========common part 1 end=============================================================

    
//XMLTool
class XMLTool{
	public boolean advancedSeparator = false;
	public String thousandsSeparator = null;
 	public String decimalSeparator =null;
	public String connName = null;
	public String cid = null;
	public boolean istWriteJSONField = false;
	
	public void getValue(XMLNode node){
		getValue(node, false);
	}
	
	public void getValue(XMLNode node, boolean parseAsArray) {
		if(!parseAsArray){

    stringBuffer.append(TEXT_21);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_22);
    stringBuffer.append(node.relatedColumn.getLabel());
    stringBuffer.append(TEXT_23);
    
		}else{

    stringBuffer.append(TEXT_24);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_22);
    stringBuffer.append(node.relatedColumn.getLabel());
    stringBuffer.append(TEXT_23);
    
		}
	}

	public void getValue(IMetadataColumn column){
		getValue(column, false);
	}
	
	public void getValue(IMetadataColumn column, boolean parseAsArray){
		JavaType javaType = JavaTypesManager.getJavaTypeFromId(column.getTalendType());
		String defaultValue=column.getDefault();
		boolean isNotSetDefault = false;
		if(defaultValue!=null){
			isNotSetDefault = defaultValue.length()==0;
		}else{
			isNotSetDefault=true;
		}

    stringBuffer.append(TEXT_25);
    
		if(column.isNullable()){

    stringBuffer.append(TEXT_26);
    stringBuffer.append(connName);
    stringBuffer.append(TEXT_27);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_28);
    
		}
		
        if(advancedSeparator && JavaTypesManager.isNumberType(javaType, column.isNullable())) { 
        	if(javaType == JavaTypesManager.BIGDECIMAL) {

    stringBuffer.append(TEXT_29);
    stringBuffer.append(connName);
    stringBuffer.append(TEXT_27);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_30);
    stringBuffer.append( thousandsSeparator);
    stringBuffer.append(TEXT_31);
    stringBuffer.append(decimalSeparator );
    stringBuffer.append(TEXT_32);
    
    		} else {

    stringBuffer.append(TEXT_33);
    stringBuffer.append(connName);
    stringBuffer.append(TEXT_27);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_34);
    stringBuffer.append( thousandsSeparator );
    stringBuffer.append(TEXT_31);
    stringBuffer.append(decimalSeparator );
    stringBuffer.append(TEXT_35);
    
	   		}
        } else if(JavaTypesManager.isJavaPrimitiveType( column.getTalendType(), column.isNullable())){

    stringBuffer.append(TEXT_36);
    stringBuffer.append(connName);
    stringBuffer.append(TEXT_27);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_37);
    
        }else if(javaType == JavaTypesManager.DATE){
            if( column.getPattern() != null && column.getPattern().trim().length() != 0 ){

    stringBuffer.append(TEXT_38);
    stringBuffer.append(connName);
    stringBuffer.append(TEXT_27);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_31);
    stringBuffer.append(column.getPattern());
    stringBuffer.append(TEXT_37);
    
            }else{

    stringBuffer.append(TEXT_39);
    stringBuffer.append(connName);
    stringBuffer.append(TEXT_27);
    stringBuffer.append(column.getLabel());
    
           }
        }else if (javaType == JavaTypesManager.BIGDECIMAL) {

    stringBuffer.append(TEXT_39);
    stringBuffer.append(connName);
    stringBuffer.append(TEXT_27);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_40);
    
        }else if (javaType == JavaTypesManager.BYTE_ARRAY) {

    stringBuffer.append(TEXT_41);
    stringBuffer.append(connName);
    stringBuffer.append(TEXT_27);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_37);
    
		}else if (istWriteJSONField && javaType == JavaTypesManager.OBJECT && parseAsArray) {

    stringBuffer.append(TEXT_42);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_43);
    stringBuffer.append(connName);
    stringBuffer.append(TEXT_27);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_37);
    
		}else{

    stringBuffer.append(TEXT_44);
    stringBuffer.append(connName);
    stringBuffer.append(TEXT_27);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_45);
    
		}
		if(column.isNullable()){
			
    stringBuffer.append(TEXT_46);
     
			if(!isNotSetDefault){
				
    stringBuffer.append(column.getDefault());
    
			}else{
				
    stringBuffer.append(TEXT_47);
    
			}
		}

    stringBuffer.append(TEXT_48);
    
	}
}

// ------------------- *** Dom4j generation mode start *** ------------------- //
class GenerateToolByDom4j{
	String cid = null;
	boolean allowEmpty = false;
	boolean outputAsXSD = false;
    boolean istWriteJSONField = false;
    boolean isQuoteAllValues = false;
	XMLTool tool = null;
	public void generateCode(XMLNode node, String currEleName, String parentName){
		if(("ELEMENT").equals(node.type)){
			createElement(currEleName,node,parentName);
			setText(currEleName,node);
			for(XMLNode ns:node.namespaces){
				addNameSpace(currEleName,ns);
			}
			for(XMLNode attri:node.attributes){
				addAttribute(currEleName,attri);
			}
			if(node.name.indexOf(":")>0){

    stringBuffer.append(TEXT_39);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_50);
    stringBuffer.append(node.name);
    stringBuffer.append(TEXT_51);
    
			}
			int index = 0;
			for(XMLNode child:node.elements){
				if(0==(child.special & 1)){
					generateCode(child,currEleName+"_"+index++,currEleName);
				}
			}
		}
	}
	private void createElement(String currEleName, XMLNode node, String parentName){
		int index = node.name.indexOf(":");
		if(5==(node.special & 5)){
			int currPos = node.getCurrGroupPos();
			if(index>0 && node.parent!=null){

    stringBuffer.append(TEXT_52);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_53);
    stringBuffer.append(parentName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_54);
    stringBuffer.append(node.name.substring(0,index));
    stringBuffer.append(TEXT_55);
    stringBuffer.append(TEXT_44);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_56);
    stringBuffer.append(node.name.substring(index+1));
    stringBuffer.append(TEXT_57);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_56);
    stringBuffer.append(node.name);
    stringBuffer.append(TEXT_58);
    
			}else{

    stringBuffer.append(TEXT_52);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_56);
    stringBuffer.append(node.name);
    stringBuffer.append(TEXT_51);
    
			}

    stringBuffer.append(TEXT_59);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_60);
    stringBuffer.append(currPos );
    stringBuffer.append(TEXT_61);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_60);
    stringBuffer.append(currPos );
    stringBuffer.append(TEXT_62);
    stringBuffer.append(node.getNodeInsertIndex() );
    stringBuffer.append(TEXT_63);
    stringBuffer.append(currPos +1 );
    stringBuffer.append(TEXT_64);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_65);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_60);
    stringBuffer.append(currPos +1 );
    stringBuffer.append(TEXT_66);
    stringBuffer.append(TEXT_67);
    stringBuffer.append(parentName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_68);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_60);
    stringBuffer.append(currPos );
    stringBuffer.append(TEXT_69);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_19);
    
		}else{
			if(index>0 && node.parent!=null){

    stringBuffer.append(TEXT_52);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_53);
    stringBuffer.append(parentName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_54);
    stringBuffer.append(node.name.substring(0,index));
    stringBuffer.append(TEXT_55);
    stringBuffer.append(TEXT_44);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_70);
    stringBuffer.append(parentName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_71);
    stringBuffer.append(node.name.substring(index+1));
    stringBuffer.append(TEXT_57);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_70);
    stringBuffer.append(parentName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_71);
    stringBuffer.append(node.name);
    stringBuffer.append(TEXT_58);
    
			}else{

    stringBuffer.append(TEXT_52);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_70);
    stringBuffer.append(parentName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_71);
    stringBuffer.append(node.name);
    stringBuffer.append(TEXT_51);
    
			}
		}
		if(0!=(node.special & 2)){

    stringBuffer.append(TEXT_72);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_70);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_73);
    
		}
	}
	private void setText(String currEleName, XMLNode node){
		if(node.relatedColumn!=null){
			JavaType javaType = JavaTypesManager.getJavaTypeFromId(node.relatedColumn.getTalendType());
			if(javaType == JavaTypesManager.OBJECT){

    stringBuffer.append(TEXT_74);
    tool.getValue(node);
    stringBuffer.append(TEXT_75);
    
            if(istWriteJSONField){
                boolean parseAsArray = false;
                for (XMLNode attribute : node.attributes) {
                    if ("class".equals(attribute.name) && "array".equals(attribute.defaultValue)) {
                        parseAsArray = true;
                        break;
                    }
                }

    stringBuffer.append(TEXT_76);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_77);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_31);
    tool.getValue(node, parseAsArray);
    stringBuffer.append(TEXT_19);
    
            }else{

    stringBuffer.append(TEXT_76);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_77);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_31);
    tool.getValue(node);
    stringBuffer.append(TEXT_19);
    
            }

    stringBuffer.append(TEXT_78);
    
				if(outputAsXSD){

    stringBuffer.append(TEXT_79);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_77);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_80);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_81);
    
				}
			}else{

    stringBuffer.append(TEXT_74);
    tool.getValue(node);
    stringBuffer.append(TEXT_82);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_83);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_31);
    tool.getValue(node);
    stringBuffer.append(TEXT_19);
    

                boolean hasCustomAttrs = false;
                for (XMLNode attribute : node.attributes) {
                    if (!"type".equals(attribute.name) && !"class".equals(attribute.name)) {
                    
    stringBuffer.append(TEXT_84);
    stringBuffer.append( node.name );
    stringBuffer.append(TEXT_85);
    stringBuffer.append( attribute.name );
    
                        hasCustomAttrs = true;
                        break;
                    }
                }
			if(istWriteJSONField && allowEmptyStrings) {
				if (javaType == JavaTypesManager.STRING 
                    && (!hasCustomAttrs)
                    && (node.elements == null || node.elements.size() == 0)) {
				
    stringBuffer.append(TEXT_39);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_86);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_87);
    
				}
			}


                if (istWriteJSONField && !isQuoteAllValues && !hasCustomAttrs) {
                    if (javaType == JavaTypesManager.BOOLEAN) {

    stringBuffer.append(TEXT_44);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_88);
    
                    } else if (JavaTypesManager.isNumberType(javaType)) {

    stringBuffer.append(TEXT_44);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_89);
    
                    }
                }

    stringBuffer.append(TEXT_90);
     			if(istWriteJSONField && allowEmptyStrings) { 
    stringBuffer.append(TEXT_91);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_83);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_92);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_93);
    
			}
				if(outputAsXSD){

    stringBuffer.append(TEXT_94);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_95);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_81);
    
				}
			}
		}else if(node.defaultValue != null && !("").equals(node.defaultValue) ){

    stringBuffer.append(TEXT_96);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_97);
    stringBuffer.append(currEleName );
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_98);
    stringBuffer.append(node.defaultValue );
    stringBuffer.append(TEXT_51);
    
		}
	}
	private void addAttribute(String currEleName, XMLNode node){
		if(node.relatedColumn!=null){

    stringBuffer.append(TEXT_74);
    tool.getValue(node);
    stringBuffer.append(TEXT_99);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_100);
    stringBuffer.append(node.path);
    stringBuffer.append(TEXT_101);
    tool.getValue(node);
    stringBuffer.append(TEXT_102);
    
		}else if(node.defaultValue != null && !("").equals(node.defaultValue) ){

    stringBuffer.append(TEXT_26);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_100);
    stringBuffer.append(node.path);
    stringBuffer.append(TEXT_103);
    stringBuffer.append(node.defaultValue );
    stringBuffer.append(TEXT_51);
    
		}
	}
	private void addNameSpace(String currEleName, XMLNode node){
		if(node.relatedColumn!=null){

    stringBuffer.append(TEXT_74);
    tool.getValue(node);
    stringBuffer.append(TEXT_99);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_104);
    stringBuffer.append(node.path);
    stringBuffer.append(TEXT_105);
    tool.getValue(node);
    stringBuffer.append(TEXT_106);
    
			if(node.path ==null || node.path.length()==0){

    stringBuffer.append(TEXT_107);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_108);
    stringBuffer.append(currEleName);
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_109);
    tool.getValue(node);
    stringBuffer.append(TEXT_110);
    
			}

    stringBuffer.append(TEXT_90);
    
		}else if(node.defaultValue != null && !("").equals(node.defaultValue) ){

    stringBuffer.append(TEXT_39);
    stringBuffer.append(currEleName );
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_104);
    stringBuffer.append(node.path );
    stringBuffer.append(TEXT_111);
    stringBuffer.append(node.defaultValue );
    stringBuffer.append(TEXT_112);
    
			if(node.path ==null || node.path.length()==0){

    stringBuffer.append(TEXT_107);
    stringBuffer.append(currEleName );
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_108);
    stringBuffer.append(currEleName );
    stringBuffer.append(TEXT_49);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_113);
    stringBuffer.append(node.defaultValue );
    stringBuffer.append(TEXT_114);
    
			}
		}
	}
}
// ------------------- *** Dom4j generation mode end *** ------------------- //

// ------------------- *** Null generation mode start *** ------------------- //
class GenerateToolByNull{
	String cid = null;
	boolean allowEmpty = false;
	boolean outputAsXSD = false;
	String fileNameXSD = "";
	XMLTool tool = null;
	
	public void generateCode(XMLNode node, String emptySpace){	
		if(("ELEMENT").equals(node.type)){
			startElement(node,emptySpace);
			setText(node);
			XMLNode mainChild = null;
			for(XMLNode child:node.elements){
				if(child.isMainNode()){ //loop dosen't have a main child node
					mainChild = child;
					break;
				}
			}
			for(XMLNode child:node.elements){
				if(mainChild!=null && mainChild.order<=child.order){ //loop dosen't have a main child node
					if(1==(node.special & 1)){ // group

    stringBuffer.append(TEXT_115);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_60);
    stringBuffer.append(node.getCurrGroupPos());
    stringBuffer.append(TEXT_116);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_117);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_118);
    
					}else{// root
    					int num = node.path.split("/").length-2;
    					if(!outputAsXSD && !allowEmpty){

    stringBuffer.append(TEXT_119);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_60);
    stringBuffer.append(num);
    stringBuffer.append(TEXT_116);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_117);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_118);
    
						}else{

    stringBuffer.append(TEXT_120);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_121);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_122);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_118);
    
						}
					}
					mainChild = null;
				}
				if(!child.isMainNode()){ //make the main node output last
					if(!outputAsXSD && !allowEmpty && (child.relatedColumn != null || child.childrenColumnList.size()>0 || child.hasDefaultValue == true)){

    stringBuffer.append(TEXT_123);
    
                    	for(IMetadataColumn column : child.childrenColumnList){
                    		
    stringBuffer.append(TEXT_124);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_22);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_125);
    
                    	}
                    	if(child.hasDefaultValue == true){
    stringBuffer.append(TEXT_126);
    }
    stringBuffer.append(TEXT_127);
    
						generateCode(child,emptySpace+whiteSpace);

    stringBuffer.append(TEXT_90);
    
            		}else{
            			generateCode(child,emptySpace+whiteSpace);
            		}
				}
			}

			if(!node.isMainNode()){ // is not main node
				endElement(node,emptySpace);
			}
		}
	}
	private void startElement(XMLNode node, String emptySpace){

    stringBuffer.append(TEXT_128);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_129);
    stringBuffer.append(rowSeparator);
    stringBuffer.append(TEXT_130);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_129);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_131);
    stringBuffer.append(node.name);
    stringBuffer.append(TEXT_51);
    
		if(outputAsXSD && node.parent==null){

    stringBuffer.append(TEXT_128);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_132);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_133);
    stringBuffer.append(fileNameXSD);
    stringBuffer.append(TEXT_134);
    
		}
		for(XMLNode ns:node.namespaces){
			addNameSpace(ns);
		}
		for(XMLNode attri:node.attributes){
			addAttribute(attri);
		}
		if(outputAsXSD && node.relatedColumn != null){

    stringBuffer.append(TEXT_74);
    tool.getValue(node);
    stringBuffer.append(TEXT_135);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_136);
    
		}

    stringBuffer.append(TEXT_128);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_137);
    
	}
	
	public void endElement(XMLNode node, String emptySpace){
		if(node.elements.size()>0){

    stringBuffer.append(TEXT_128);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_129);
    stringBuffer.append(rowSeparator);
    stringBuffer.append(TEXT_130);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_129);
    stringBuffer.append(emptySpace);
    stringBuffer.append(TEXT_138);
    stringBuffer.append(node.name);
    stringBuffer.append(TEXT_139);
    
		}else{

    stringBuffer.append(TEXT_128);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_140);
    stringBuffer.append(node.name);
    stringBuffer.append(TEXT_139);
    
		}
	}
	private void setText(XMLNode node){
		if(node.relatedColumn!=null){
			JavaType javaType = JavaTypesManager.getJavaTypeFromId(node.relatedColumn.getTalendType());
			if(javaType == JavaTypesManager.OBJECT){

    stringBuffer.append(TEXT_74);
    tool.getValue(node);
    stringBuffer.append(TEXT_141);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_142);
    tool.getValue(node);
    stringBuffer.append(TEXT_102);
    
			}else{

    stringBuffer.append(TEXT_74);
    tool.getValue(node);
    stringBuffer.append(TEXT_141);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_143);
    tool.getValue(node);
    stringBuffer.append(TEXT_144);
    
			}
		}else if(node.defaultValue !=null && !("").equals(node.defaultValue) ){

    stringBuffer.append(TEXT_128);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_129);
    stringBuffer.append(node.defaultValue );
    stringBuffer.append(TEXT_51);
    
		}
	}
	private void addAttribute(XMLNode node){
		if(node.relatedColumn!=null){

    stringBuffer.append(TEXT_74);
    tool.getValue(node);
    stringBuffer.append(TEXT_141);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_145);
    stringBuffer.append(node.path);
    stringBuffer.append(TEXT_146);
    tool.getValue(node);
    stringBuffer.append(TEXT_147);
    
		}else if(node.defaultValue !=null && !("").equals(node.defaultValue) ){

    stringBuffer.append(TEXT_128);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_145);
    stringBuffer.append(node.path);
    stringBuffer.append(TEXT_148);
    stringBuffer.append(node.defaultValue );
    stringBuffer.append(TEXT_149);
    
		}
	}
	private void addNameSpace(XMLNode node){
		if(node.relatedColumn!=null){

    stringBuffer.append(TEXT_74);
    tool.getValue(node);
    stringBuffer.append(TEXT_75);
    
			if(node.path ==null || node.path.length()==0){

    stringBuffer.append(TEXT_150);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_151);
    tool.getValue(node);
    stringBuffer.append(TEXT_152);
    
			}else{

    stringBuffer.append(TEXT_153);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_154);
    stringBuffer.append(node.path);
    stringBuffer.append(TEXT_146);
    tool.getValue(node);
    stringBuffer.append(TEXT_152);
    
			}

    stringBuffer.append(TEXT_90);
    
		}else if(node.defaultValue !=null && !("").equals(node.defaultValue) ){
			if(node.path ==null || node.path.length()==0){

    stringBuffer.append(TEXT_150);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_155);
    stringBuffer.append(node.defaultValue );
    stringBuffer.append(TEXT_149);
    
			}else{

    stringBuffer.append(TEXT_153);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_154);
    stringBuffer.append(node.path);
    stringBuffer.append(TEXT_148);
    stringBuffer.append(node.defaultValue );
    stringBuffer.append(TEXT_149);
    
			}
		}
	}
}
// ------------------- *** Null generation mode end *** ------------------- //

// ------------------- *** Common code start *** ------------------- //
IMetadataTable metadata = null;
IConnection inConn = null;
for (IConnection conn : node.getIncomingConnections()) {
	if (conn.getLineStyle().hasConnectionCategory(IConnectionCategory.FLOW)) {
		inConn = conn;
		break;
	}
}
if (inConn != null) {
	metadata = inConn.getMetadataTable();
    if (metadata!=null) {
    	List< ? extends IConnection> conns = node.getIncomingConnections();
    	List< ? extends IConnection> connsOut = NodeUtil.getOutgoingConnections(node,EConnectionType.ON_COMPONENT_OK);
    	String rowStructNameOutput = null;
    	if (connsOut != null && connsOut.size() > 0 && istWriteJSONField) {
    		List< ? extends IConnection> connsTarget = connsOut.get(0).getTarget().getOutgoingConnections();
			if(connsTarget != null && connsTarget.size()>0){
				rowStructNameOutput = connsTarget.get(0).getName();
	    		rowStructNameOutput += "Struct";
			}
    	}
    	String rowNameInput = null;
    	String rowStructNameInput = null;
    	if(conns!=null && conns.size()>0){
    		IConnection conn = conns.get(0);
    		rowNameInput = conn.getName();
    		rowStructNameInput = rowNameInput + "Struct";
    		if(conn.getLineStyle().hasConnectionCategory(IConnectionCategory.DATA)){ 
    		
            	List<Map<String, String>> rootTable = 
                	(List<Map<String,String>>)ElementParameterParser.getObjectValue(node, "__ROOT__");
                List<Map<String, String>> groupTable = 
                	(List<Map<String,String>>)ElementParameterParser.getObjectValue(node, "__GROUP__");
                List<Map<String, String>> loopTable = 
                	(List<Map<String,String>>)ElementParameterParser.getObjectValue(node, "__LOOP__");
                
                IMetadataTable inputMetadataTable= conn.getMetadataTable();
                List<IMetadataColumn> inputColumns= inputMetadataTable.getListColumns();
                
                List<Map<String,String>> groupbys = (List<Map<String,String>>)ElementParameterParser.getObjectValue(node, "__GROUPBYS__");
				
				String removeHeader = ElementParameterParser.getValue(node, "__REMOVE_HEADER__"); // add for feature7788
                String allowEmpty = ElementParameterParser.getValue(node, "__CREATE_EMPTY_ELEMENT__");
                String outputAsXSD = ElementParameterParser.getValue(node, "__OUTPUT_AS_XSD__");
                String fileNameXSD = ElementParameterParser.getValue(node, "__XSD_FILE__");
                String encoding = ElementParameterParser.getValue(node, "__ENCODING__");                
                
	            String rowNumber = ElementParameterParser.getValue(node, "__ROW_NUMBER__");
                
                String advancedSeparatorStr = ElementParameterParser.getValue(node, "__ADVANCED_SEPARATOR__");
        		boolean advancedSeparator = (advancedSeparatorStr!=null&&!("").equals(advancedSeparatorStr))?("true").equals(advancedSeparatorStr):false;
        		String thousandsSeparator = ElementParameterParser.getValueWithJavaType(node, "__THOUSANDS_SEPARATOR__", JavaTypesManager.CHARACTER);
        		String decimalSeparator = ElementParameterParser.getValueWithJavaType(node, "__DECIMAL_SEPARATOR__", JavaTypesManager.CHARACTER); 
        		
        		String mode = ElementParameterParser.getValue(node, "__GENERATION_MODE__");
        		
        		boolean storeFlow = ("true").equals(ElementParameterParser.getValue(node, "__STORE_FLOW__"));
        		                
                java.util.Map<String,IMetadataColumn> inputKeysColumns = new java.util.HashMap<String,IMetadataColumn>();
                if(inputColumns!=null){
                	for(IMetadataColumn column :inputColumns){
                		for(int i=0;i<groupbys.size();i++){
                			String columnName=groupbys.get(i).get("INPUT_COLUMN");
                			if(column.getLabel().equals(columnName)){
                				inputKeysColumns.put(columnName,column);
                				break;
                			}
                		}
                	}
                }
        		
                String destination = ElementParameterParser.getValue(node, "__DESTINATION__");
        		// init tool
                XMLTool tool = new XMLTool();
                tool.connName = conn.getName();
                tool.advancedSeparator=advancedSeparator;
                tool.thousandsSeparator=thousandsSeparator;
                tool.decimalSeparator=decimalSeparator;
                tool.cid=cid;
                tool.istWriteJSONField = istWriteJSONField;
                
                // change tables to a tree 
				Object[] treeObjs = getTree(rootTable, groupTable, loopTable, metadata.getListColumns());
            	List<XMLNode> mainList = (ArrayList<XMLNode>)treeObjs[0];
                List<XMLNode> groupList = (ArrayList<XMLNode>)treeObjs[1];
                XMLNode root = mainList.get(0);
            	XMLNode loop = (XMLNode)treeObjs[2];
                
                if(!("true").equals(allowEmpty)){
                	removeEmptyElement(root);
                }
                
                List<List<XMLNode>> groupbyNodeList = new ArrayList<List<XMLNode>>();
                for(XMLNode group:groupList){
                	groupbyNodeList.add(getGroupByNodeList(group));
                }
                IConnection nextMergeConn = NodeUtil.getNextMergeConnection(node);
				if(nextMergeConn == null || nextMergeConn.getInputId()==1){

    stringBuffer.append(TEXT_156);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_157);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_158);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_159);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_160);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_161);
    
				}

    stringBuffer.append(TEXT_162);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_163);
    
	log4jFileUtil.logCurrentRowNumberInfo();

    stringBuffer.append(TEXT_164);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_165);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_166);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_167);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_168);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_169);
    
	if (istWriteJSONField) {

    stringBuffer.append(TEXT_170);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_169);
    
	}
				for(IMetadataColumn column :inputColumns){

    stringBuffer.append(TEXT_171);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_172);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_173);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_174);
     tool.getValue(column); 
    stringBuffer.append(TEXT_106);
    
	if (istWriteJSONField) {

    stringBuffer.append(TEXT_170);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_172);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_173);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_174);
     tool.getValue(column, true); 
    stringBuffer.append(TEXT_106);
    
	}
				}

    if(storeFlow){
    stringBuffer.append(TEXT_175);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_176);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_177);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_178);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_179);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_19);
    }
    stringBuffer.append(TEXT_180);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_181);
    
	if(inputKeysColumns.size() !=0){
		for (IMetadataColumn column : inputColumns) {
			if(inputKeysColumns.containsKey(column.getLabel())) {

    stringBuffer.append(TEXT_182);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_183);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_184);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_22);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_185);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_22);
    stringBuffer.append(column.getLabel() );
    stringBuffer.append(TEXT_186);
    			}
		}
	}

    stringBuffer.append(TEXT_187);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_188);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_189);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_190);
    
		if(istWriteJSONField){
            for(Map<String,String> map : groupbys){
            	String groupByColumnName = map.get("INPUT_COLUMN");
            	String outputColumnName = map.get("OUTPUT_COLUMN");
            	if (!outputColumnName.equals(jsonField)) {
            	
    stringBuffer.append(TEXT_191);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_27);
    stringBuffer.append( groupByColumnName );
    stringBuffer.append(TEXT_70);
    stringBuffer.append( rowNameInput );
    stringBuffer.append(TEXT_27);
    stringBuffer.append( groupByColumnName );
    stringBuffer.append(TEXT_192);
    
            	}
            }
		}
		
    stringBuffer.append(TEXT_193);
    
// ------------------- *** Common code end *** ------------------- //

// ------------------- *** Dom4j generation mode start *** ------------------- //
if(("Dom4j").equals(mode)){
		if(inputKeysColumns.size() !=0){

    stringBuffer.append(TEXT_194);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_195);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_196);
    		}
		if(("true").equals(outputAsXSD)){

    stringBuffer.append(TEXT_197);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_198);
    stringBuffer.append(fileNameXSD);
    stringBuffer.append(TEXT_199);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_200);
    
		}

    stringBuffer.append(TEXT_201);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_202);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_203);
    
		if(!("true").equals(outputAsXSD) && !("true").equals(allowEmpty)){

    stringBuffer.append(TEXT_204);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_205);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_203);
    
		}

    stringBuffer.append(TEXT_206);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_207);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_208);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_209);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_210);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_211);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_212);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_213);
    
		if(("true").equals(removeHeader)){

    stringBuffer.append(TEXT_214);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_215);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_216);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_217);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_218);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_219);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_220);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_221);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_19);
    
		}else{
            if(destination!=null && (destination.indexOf("tCouchbaseOutput_")==0) || destination.indexOf("tCouchDBOutput_")==0){

    stringBuffer.append(TEXT_222);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_223);
    stringBuffer.append(destination);
    stringBuffer.append(TEXT_224);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_225);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_226);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_19);
    
            }else{
				if(istWriteJSONField){
					
    stringBuffer.append(TEXT_227);
    stringBuffer.append( rowStructNameOutput );
    stringBuffer.append(TEXT_228);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_229);
    stringBuffer.append( rowStructNameOutput );
    stringBuffer.append(TEXT_230);
    
					      for(Map<String,String> map : groupbys){
								String groupByColumnName = map.get("INPUT_COLUMN");
								String outputColumnName = map.get("OUTPUT_COLUMN");
								if (!outputColumnName.equals(jsonField)) {
								
    stringBuffer.append(TEXT_231);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_27);
    stringBuffer.append( outputColumnName );
    stringBuffer.append(TEXT_232);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_27);
    stringBuffer.append( groupByColumnName );
    stringBuffer.append(TEXT_233);
    
								}
					     }
					
    stringBuffer.append(TEXT_234);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_27);
    stringBuffer.append( jsonField );
    stringBuffer.append(TEXT_215);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_235);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_236);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_237);
    
				}else{
								
    stringBuffer.append(TEXT_238);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_239);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_240);
    
				}
            }
		}

    stringBuffer.append(TEXT_241);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_242);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_243);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_244);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_245);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_246);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_247);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_249);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_250);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_251);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_252);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_189);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_73);
    
		if(istWriteJSONField){
			for(Map<String,String> map : groupbys){
            	String groupByColumnName = map.get("INPUT_COLUMN");
            	String outputColumnName = map.get("OUTPUT_COLUMN");
            	if (!outputColumnName.equals(jsonField)) {
            	
    stringBuffer.append(TEXT_191);
    stringBuffer.append( cid );
    stringBuffer.append(TEXT_27);
    stringBuffer.append( groupByColumnName );
    stringBuffer.append(TEXT_70);
    stringBuffer.append( rowNameInput );
    stringBuffer.append(TEXT_27);
    stringBuffer.append( groupByColumnName );
    stringBuffer.append(TEXT_192);
    
            	}
            }
		}
		if(inputKeysColumns.size() !=0){

    stringBuffer.append(TEXT_90);
    
		}

    stringBuffer.append(TEXT_253);
    
	//init the generate tool.
	GenerateToolByDom4j generateToolByDom4j = new GenerateToolByDom4j();
    if(("true").equals(outputAsXSD)){
    	generateToolByDom4j.outputAsXSD = true;
    }
    if(("true").equals(allowEmpty)){
    	generateToolByDom4j.allowEmpty = true;
    }
    generateToolByDom4j.istWriteJSONField = istWriteJSONField;
    generateToolByDom4j.isQuoteAllValues = isQuoteAllValues;
    generateToolByDom4j.cid = cid;
    generateToolByDom4j.tool = tool;
    
    //start generate code
    if(destination!=null && (destination.indexOf("tCouchbaseOutput_")==0 || destination.indexOf("tCouchDBOutput_")==0)){
        INode previousNode = conn.getSource();
        List<IMetadataTable> previous_metadatas = previousNode.getMetadataList();
        if ((previous_metadatas!=null)&&(previous_metadatas.size()>0)) {
            IMetadataTable previous_metadata = previous_metadatas.get(0);
            if (previous_metadata!=null) {
                List<IMetadataColumn> columnList = previous_metadata.getListColumns();

    stringBuffer.append(TEXT_222);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_254);
    
                for(IMetadataColumn colum: columnList){

    stringBuffer.append(TEXT_255);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_172);
    stringBuffer.append(colum.getLabel());
    stringBuffer.append(TEXT_101);
    stringBuffer.append(conn.getName());
    stringBuffer.append(TEXT_27);
    stringBuffer.append(colum.getLabel());
    stringBuffer.append(TEXT_19);
    
                }
            }
        }
    }

    stringBuffer.append(TEXT_256);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_257);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_258);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_259);
    
	generateToolByDom4j.generateCode(root,"root","doc");

    stringBuffer.append(TEXT_260);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_261);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_262);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_263);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_264);
    
	if(groupTable.size()>0){

    stringBuffer.append(TEXT_265);
    
	}
	for(int i=0;i<groupList.size();i++){
		XMLNode groupRootNode = groupList.get(i);

    stringBuffer.append(TEXT_266);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_267);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_268);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_269);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_270);
    
		for(int j=0;j<groupbyNodeList.get(i).size();j++){
			XMLNode attr = groupbyNodeList.get(i).get(j);
			if(attr.relatedColumn!=null){

    stringBuffer.append(TEXT_271);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_269);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_272);
    stringBuffer.append(j);
    stringBuffer.append(TEXT_273);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_269);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_272);
    stringBuffer.append(j);
    stringBuffer.append(TEXT_274);
    tool.getValue(attr);
    stringBuffer.append(TEXT_275);
    tool.getValue(attr);
    stringBuffer.append(TEXT_276);
    
			}
		}

    stringBuffer.append(TEXT_277);
    
		generateToolByDom4j.generateCode(groupList.get(i),"group"+i+"_","subTreeRootParent");

    stringBuffer.append(TEXT_278);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_267);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_279);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_280);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_269);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_281);
    
		for(int j=0;j<groupbyNodeList.get(i).size();j++){
			XMLNode attr = groupbyNodeList.get(i).get(j);

    stringBuffer.append(TEXT_282);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_269);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_283);
    tool.getValue(attr);
    stringBuffer.append(TEXT_19);
    
		}

    stringBuffer.append(TEXT_284);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_267);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_285);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_286);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_287);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_288);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_289);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_290);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_287);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_291);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_292);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_269);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_293);
    
	}

    stringBuffer.append(TEXT_294);
    
	generateToolByDom4j.generateCode(loop,"loop","subTreeRootParent");
}
// ------------------- *** Dom4j generation mode end *** ------------------- //

// ------------------- *** Null generation mode start *** ------------------- //
else if(("Null").equals(mode)){
//	String fileNameXSD = ElementParameterParser.getValue(node, "__XSD_FILE__");
	//init the generate tool.
	GenerateToolByNull generateToolByNull = new GenerateToolByNull();
    if(("true").equals(outputAsXSD)){
    	generateToolByNull.outputAsXSD = true;
    	generateToolByNull.fileNameXSD = fileNameXSD;
    }
    if(("true").equals(allowEmpty)){
    	generateToolByNull.allowEmpty = true;
    }
    generateToolByNull.cid = cid;
    generateToolByNull.tool = tool;

	if(inputKeysColumns.size() !=0){
	
    stringBuffer.append(TEXT_194);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_195);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_295);
    	}
    
		if(!("true").equals(outputAsXSD) && !("true").equals(allowEmpty)){

    stringBuffer.append(TEXT_296);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_297);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_298);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_299);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_300);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_301);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_302);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_303);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_304);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_302);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_305);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_306);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_307);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_308);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_309);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_310);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_311);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_312);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_313);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_314);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_315);
    stringBuffer.append(rowSeparator);
    stringBuffer.append(TEXT_316);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_317);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_318);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_319);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_320);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_321);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_310);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_311);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_312);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_313);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_322);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_315);
    stringBuffer.append(rowSeparator);
    stringBuffer.append(TEXT_316);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_317);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_318);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_323);
    
		}else{
			if(loopTable.size()>0){

    stringBuffer.append(TEXT_324);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_325);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_326);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_310);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_327);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_328);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_313);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_329);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_315);
    stringBuffer.append(rowSeparator);
    stringBuffer.append(TEXT_330);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_317);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_318);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_331);
    
			}
		}

    stringBuffer.append(TEXT_324);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_332);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_333);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_334);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_335);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_336);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_337);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_338);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_315);
    stringBuffer.append(rowSeparator);
    stringBuffer.append(TEXT_339);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_340);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_239);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_341);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_342);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_343);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_19);
    
	if(!("true").equals(removeHeader)){

    stringBuffer.append(TEXT_120);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_344);
    stringBuffer.append(encoding );
    stringBuffer.append(TEXT_345);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_315);
    stringBuffer.append(rowSeparator);
    stringBuffer.append(TEXT_51);
    
	}

    stringBuffer.append(TEXT_346);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_347);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_189);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_348);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_349);
    	if(inputKeysColumns.size() !=0){
    stringBuffer.append(TEXT_90);
    	}
    stringBuffer.append(TEXT_350);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_351);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_352);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_258);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_259);
    
	String rootEmptySpace = "";
	for(int i=0;i<mainList.size();i++){
		generateToolByNull.generateCode(mainList.get(i),rootEmptySpace);
		rootEmptySpace+=whiteSpace;
		
		if(!generateToolByNull.outputAsXSD && !generateToolByNull.allowEmpty){
			if(mainList.get(i).relatedColumn != null || mainList.get(i).childrenColumnList.size()>0){

    stringBuffer.append(TEXT_123);
    
                	for(IMetadataColumn column : mainList.get(i).childrenColumnList){
                		
    stringBuffer.append(TEXT_124);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_22);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_125);
    
                	}

    stringBuffer.append(TEXT_353);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_70);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_354);
    
			}
		}

    stringBuffer.append(TEXT_355);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_60);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_116);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_356);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_118);
    

	}

    stringBuffer.append(TEXT_357);
    
	if(groupTable.size()>0){

    stringBuffer.append(TEXT_358);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_359);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_360);
    stringBuffer.append(groupList.size());
    stringBuffer.append(TEXT_361);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_360);
    stringBuffer.append(groupList.size());
    stringBuffer.append(TEXT_362);
    
	}
	for(int i=0;i<groupList.size();i++){
		XMLNode groupRootNode = groupList.get(i);

    stringBuffer.append(TEXT_363);
    stringBuffer.append(groupRootNode.name);
    stringBuffer.append(TEXT_364);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_267);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_268);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_269);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_270);
    
		for(int j=0;j<groupbyNodeList.get(i).size();j++){
			XMLNode attr = groupbyNodeList.get(i).get(j);
			if(attr.relatedColumn!=null){

    stringBuffer.append(TEXT_271);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_269);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_272);
    stringBuffer.append(j);
    stringBuffer.append(TEXT_273);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_269);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_272);
    stringBuffer.append(j);
    stringBuffer.append(TEXT_274);
    tool.getValue(attr);
    stringBuffer.append(TEXT_275);
    tool.getValue(attr);
    stringBuffer.append(TEXT_276);
    
			}
		}

    stringBuffer.append(TEXT_365);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_366);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_367);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_70);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_368);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_267);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_279);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_280);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_269);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_281);
    
		for(int j=0;j<groupbyNodeList.get(i).size();j++){
			XMLNode attr = groupbyNodeList.get(i).get(j);

    stringBuffer.append(TEXT_282);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_269);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_283);
    tool.getValue(attr);
    stringBuffer.append(TEXT_19);
    
		}

    stringBuffer.append(TEXT_369);
    
		String emptySpace = "";
		for(int len = groupList.get(i).path.split("/").length-1;len>1;len--){
			emptySpace +=whiteSpace;
		}
		generateToolByNull.generateCode(groupList.get(i),emptySpace);
		
		if(!("true").equals(outputAsXSD) && !("true").equals(allowEmpty)){
			if((groupList.get(i).relatedColumn != null || groupList.get(i).childrenColumnList.size()>0)){

    stringBuffer.append(TEXT_370);
    
            	for(IMetadataColumn column : groupList.get(i).childrenColumnList){
            		
    stringBuffer.append(TEXT_124);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_22);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_125);
    
            	}

    stringBuffer.append(TEXT_371);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_70);
    stringBuffer.append(i+mainList.size());
    stringBuffer.append(TEXT_372);
    
			}
		}

    stringBuffer.append(TEXT_373);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_60);
    stringBuffer.append(i);
    stringBuffer.append(TEXT_116);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_374);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_118);
    
	}//End of groupList loop
	
	if(groupTable.size()>0){

    stringBuffer.append(TEXT_375);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_376);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_377);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_378);
    
		if(!("true").equals(outputAsXSD) && !("true").equals(allowEmpty)){

    stringBuffer.append(TEXT_379);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_380);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_332);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_381);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_334);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_382);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_299);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_383);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_384);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_304);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_385);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_386);
    
		}else{

    stringBuffer.append(TEXT_387);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_332);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_381);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_334);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_388);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_389);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_304);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_390);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_391);
    
		}
		if(!("true").equals(outputAsXSD) && !("true").equals(allowEmpty)){

    stringBuffer.append(TEXT_392);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_393);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_394);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_395);
    stringBuffer.append(mainList.size());
    stringBuffer.append(TEXT_396);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_397);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_320);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_321);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_395);
    stringBuffer.append(mainList.size());
    stringBuffer.append(TEXT_396);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_321);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_398);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_399);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_313);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_400);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_401);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_315);
    stringBuffer.append(rowSeparator);
    stringBuffer.append(TEXT_402);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_317);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_403);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_404);
    
		}

    stringBuffer.append(TEXT_405);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_308);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_309);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_395);
    stringBuffer.append(mainList.size());
    stringBuffer.append(TEXT_396);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_321);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_398);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_399);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_313);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_400);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_401);
    stringBuffer.append(cid );
    stringBuffer.append(TEXT_315);
    stringBuffer.append(rowSeparator);
    stringBuffer.append(TEXT_402);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_317);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_403);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_406);
    
		if(!("true").equals(outputAsXSD) && !("true").equals(allowEmpty)){

    stringBuffer.append(TEXT_78);
    
		}

    stringBuffer.append(TEXT_407);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_408);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_409);
    stringBuffer.append(mainList.size());
    stringBuffer.append(TEXT_410);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_332);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_411);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_334);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_412);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_393);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_413);
    stringBuffer.append(mainList.size());
    stringBuffer.append(TEXT_414);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_409);
    stringBuffer.append(mainList.size());
    stringBuffer.append(TEXT_415);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_416);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_409);
    stringBuffer.append(mainList.size());
    stringBuffer.append(TEXT_417);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_418);
    
	}
	if(!("true").equals(outputAsXSD) && !("true").equals(allowEmpty)){

    stringBuffer.append(TEXT_419);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_420);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_421);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_422);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_423);
    stringBuffer.append(mainList.size()-1);
    stringBuffer.append(TEXT_424);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_425);
    stringBuffer.append(mainList.size()-1);
    stringBuffer.append(TEXT_426);
    
	}

    stringBuffer.append(TEXT_294);
    
	String emptySpace = "";
	for(int len =loop.path.split("/").length-1;len>1;len--){
		emptySpace +=whiteSpace;
	}
	if(!("true").equals(outputAsXSD) && !("true").equals(allowEmpty)){

    stringBuffer.append(TEXT_123);
    
    	for(IMetadataColumn column : loop.childrenColumnList){
    		
    stringBuffer.append(TEXT_124);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_22);
    stringBuffer.append(column.getLabel());
    stringBuffer.append(TEXT_125);
    
    	}
    	if(loop.hasDefaultValue == true){
    stringBuffer.append(TEXT_427);
    }
    stringBuffer.append(TEXT_127);
    
	}
	generateToolByNull.generateCode(loop,emptySpace);
	generateToolByNull.endElement(loop,emptySpace);

    stringBuffer.append(TEXT_428);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_332);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_381);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_334);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_388);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_429);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_430);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_304);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_431);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_248);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_432);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_121);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_433);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_70);
    stringBuffer.append(groupList.size()+mainList.size());
    stringBuffer.append(TEXT_73);
    
	if(!("true").equals(outputAsXSD) && !("true").equals(allowEmpty)){

    stringBuffer.append(TEXT_434);
    stringBuffer.append(cid);
    stringBuffer.append(TEXT_70);
    stringBuffer.append(groupList.size()+mainList.size()-1);
    stringBuffer.append(TEXT_354);
    
	}
}
// ------------------- *** Null generation mode end *** ------------------- //

// ------------------- *** Common code start *** ------------------- //
			}
		}
	}
}
// ------------------- *** Common code end *** ------------------- //

    stringBuffer.append(TEXT_435);
    return stringBuffer.toString();
  }
}
